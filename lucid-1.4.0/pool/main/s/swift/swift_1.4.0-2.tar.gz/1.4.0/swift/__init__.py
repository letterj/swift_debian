import gettext


__version__ = '1.4.0'
gettext.install('swift')
